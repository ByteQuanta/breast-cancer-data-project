# ========================
# 2. GridSearchCV vs RandomizedSearchCV vs Optuna
# ========================
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

pipeline = Pipeline([
    ("scaler", RobustScaler()),
    ("lda", LDA(n_components=1)),
    ("clf", DecisionTreeClassifier(random_state=42))
])

# --- GridSearch ---
param_grid = {
    "clf__criterion": ["gini", "entropy"],
    "clf__max_depth": [2, 4, 6, 8, 10, None],
    "clf__min_samples_split": [2, 5, 10, 20],
    "clf__min_samples_leaf": [1, 2, 4, 8],
    "clf__max_features": [None, "sqrt", "log2"]
}

grid_search = GridSearchCV(pipeline, param_grid, cv=5, scoring="f1", n_jobs=-1)
grid_search.fit(X_train, y_train)

y_pred_grid = grid_search.predict(X_test)
grid_f1 = f1_score(y_test, y_pred_grid)
grid_acc = accuracy_score(y_test, y_pred_grid)
grid_auc = roc_auc_score(y_test, grid_search.predict_proba(X_test)[:, 1])

# --- RandomizedSearch ---
param_dist = {
    "clf__criterion": ["gini", "entropy"],
    "clf__max_depth": np.arange(2, 20),
    "clf__min_samples_split": np.arange(2, 20),
    "clf__min_samples_leaf": np.arange(1, 10),
    "clf__max_features": [None, "sqrt", "log2"]
}

random_search = RandomizedSearchCV(
    pipeline, param_distributions=param_dist, n_iter=50,
    cv=5, scoring="f1", random_state=42, n_jobs=-1
)
random_search.fit(X_train, y_train)

y_pred_random = random_search.predict(X_test)
random_f1 = f1_score(y_test, y_pred_random)
random_acc = accuracy_score(y_test, y_pred_random)
random_auc = roc_auc_score(y_test, random_search.predict_proba(X_test)[:, 1])


# ========================
# 3. Optuna
# ========================
def objective(trial):
    criterion = trial.suggest_categorical("criterion", ["gini", "entropy"])
    max_depth = trial.suggest_int("max_depth", 2, 20)
    min_samples_split = trial.suggest_int("min_samples_split", 2, 20)
    min_samples_leaf = trial.suggest_int("min_samples_leaf", 1, 10)
    max_features = trial.suggest_categorical("max_features", [None, "sqrt", "log2"])

    pipeline = Pipeline([
        ("scaler", RobustScaler()),
        ("lda", LDA(n_components=1)),
        ("clf", DecisionTreeClassifier(
            criterion=criterion, max_depth=max_depth,
            min_samples_split=min_samples_split,
            min_samples_leaf=min_samples_leaf,
            max_features=max_features,
            random_state=42
        ))
    ])
    scores = cross_val_score(pipeline, X_train, y_train, cv=5, scoring="f1", n_jobs=-1)
    return scores.mean()

study = optuna.create_study(direction="maximize")
study.optimize(objective, n_trials=50)

best_params = study.best_params
best_pipeline = Pipeline([
    ("scaler", RobustScaler()),
    ("lda", LDA(n_components=1)),
    ("clf", DecisionTreeClassifier(**best_params, random_state=42))
])
best_pipeline.fit(X_train, y_train)

y_pred_optuna = best_pipeline.predict(X_test)
optuna_f1 = f1_score(y_test, y_pred_optuna)
optuna_acc = accuracy_score(y_test, y_pred_optuna)
optuna_auc = roc_auc_score(y_test, best_pipeline.predict_proba(X_test)[:, 1])

# ----------------
# 4. Present the results in a table
# ----------------
results = pd.DataFrame([
    {"Method": "GridSearch", "Best Params": grid_search.best_params_, "Test F1": grid_f1, "Test Acc": grid_acc, "Test AUC": grid_auc},
    {"Method": "RandomizedSearch", "Best Params": random_search.best_params_, "Test F1": random_f1, "Test Acc": random_acc, "Test AUC": random_auc},
    {"Method": "Optuna (Pipeline)", "Best Params": best_params, "Test F1": optuna_f1, "Test Acc": optuna_acc, "Test AUC": optuna_auc}
])

print("\n=== Model Comparison (F1, Accuracy, AUC) ===")
print(results)


# ========================
# 5. Optuna
# ========================
def objective_dt(trial):
    criterion = trial.suggest_categorical('criterion', ['gini', 'entropy'])
    max_depth = trial.suggest_int('max_depth', 2, 20)
    min_samples_split = trial.suggest_int('min_samples_split', 2, 20)
    min_samples_leaf = trial.suggest_int('min_samples_leaf', 1, 10)
    max_features = trial.suggest_categorical('max_features', [None, 'sqrt', 'log2'])
    class_weight = trial.suggest_categorical('class_weight', [None, 'balanced'])

    pipeline = Pipeline([
        ("scaler", RobustScaler()),
        ("lda", LDA(n_components=1)),
        ("clf", DecisionTreeClassifier(
            criterion=criterion, max_depth=max_depth,
            min_samples_split=min_samples_split,
            min_samples_leaf=min_samples_leaf,
            max_features=max_features, class_weight=class_weight,
            random_state=42
        ))
    ])
    scores = cross_val_score(pipeline, X_train, y_train, cv=5, scoring="f1", n_jobs=-1)
    return scores.mean()

study_dt = optuna.create_study(direction="maximize")
study_dt.optimize(objective_dt, n_trials=50)

best_dt = Pipeline([
    ("scaler", RobustScaler()),
    ("lda", LDA(n_components=1)),
    ("clf", DecisionTreeClassifier(**study_dt.best_params, random_state=42))
])
best_dt.fit(X_train, y_train)


def objective_rf(trial):
    n_estimators = trial.suggest_int("n_estimators", 50, 500, step=50)
    max_depth = trial.suggest_int("max_depth", 3, 30)
    min_samples_split = trial.suggest_int("min_samples_split", 2, 20)
    min_samples_leaf = trial.suggest_int("min_samples_leaf", 1, 10)
    max_features = trial.suggest_categorical("max_features", [None, "sqrt", "log2"])
    criterion = trial.suggest_categorical("criterion", ["gini", "entropy"])
    class_weight = trial.suggest_categorical("class_weight", [None, "balanced"])

    pipeline = Pipeline([
        ("scaler", RobustScaler()),
        ("lda", LDA(n_components=1)),
        ("clf", RandomForestClassifier(
            n_estimators=n_estimators, max_depth=max_depth,
            min_samples_split=min_samples_split,
            min_samples_leaf=min_samples_leaf, max_features=max_features,
            criterion=criterion, class_weight=class_weight,
            random_state=42, n_jobs=-1
        ))
    ])
    scores = cross_val_score(pipeline, X_train, y_train, cv=5, scoring="f1", n_jobs=-1)
    return scores.mean()

study_rf = optuna.create_study(direction="maximize")
study_rf.optimize(objective_rf, n_trials=50)

best_rf = Pipeline([
    ("scaler", RobustScaler()),
    ("lda", LDA(n_components=1)),
    ("clf", RandomForestClassifier(**study_rf.best_params, random_state=42, n_jobs=-1))
])
best_rf.fit(X_train, y_train)


# ========================
# 5b. Optuna (Random Forest Raw vs LDA comparision)
# ========================
def objective_rf_raw(trial):
    n_estimators = trial.suggest_int("n_estimators", 50, 500, step=50)
    max_depth = trial.suggest_int("max_depth", 3, 30)
    min_samples_split = trial.suggest_int("min_samples_split", 2, 20)
    min_samples_leaf = trial.suggest_int("min_samples_leaf", 1, 10)
    max_features = trial.suggest_categorical("max_features", [None, "sqrt", "log2"])
    criterion = trial.suggest_categorical("criterion", ["gini", "entropy"])
    class_weight = trial.suggest_categorical("class_weight", [None, "balanced"])

    pipeline = Pipeline([
        ("scaler", RobustScaler()),
        ("clf", RandomForestClassifier(
            n_estimators=n_estimators, max_depth=max_depth,
            min_samples_split=min_samples_split,
            min_samples_leaf=min_samples_leaf, max_features=max_features,
            criterion=criterion, class_weight=class_weight,
            random_state=42, n_jobs=-1
        ))
    ])
    scores = cross_val_score(pipeline, X_train, y_train, cv=5, scoring="f1", n_jobs=-1)
    return scores.mean()

study_rf_raw = optuna.create_study(direction="maximize")
study_rf_raw.optimize(objective_rf_raw, n_trials=50)

best_rf_raw = Pipeline([
    ("scaler", RobustScaler()),
    ("clf", RandomForestClassifier(**study_rf_raw.best_params, random_state=42, n_jobs=-1))
])
best_rf_raw.fit(X_train, y_train)
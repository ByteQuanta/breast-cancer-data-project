# ========================
# 1. Data Preparation
# ========================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.preprocessing import RobustScaler
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.pipeline import Pipeline
from sklearn.metrics import (accuracy_score, f1_score, roc_auc_score, confusion_matrix, roc_curve, auc,precision_recall_curve, average_precision_score)

import optuna
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.ensemble import RandomForestClassifier


# --- Dataset ---
df = pd.read_csv("breast-cancer.csv")
df["diagnosis"] = df["diagnosis"].map({"M": 1, "B": 0})
df = df.drop(columns=["id"])

from ydata_profiling import ProfileReport

# Generate a profile report
profile = ProfileReport(df, title="Breast Cancer EDA Report", explorative=True)

# save it as HTML
profile.to_file("eda_report.html")

X = df.drop(columns=["diagnosis"])
y = df["diagnosis"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)


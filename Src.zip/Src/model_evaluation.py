# ========================
# 6. Test Performances
# ========================
y_pred_dt = best_dt.predict(X_test)
y_prob_dt = best_dt.predict_proba(X_test)[:, 1]

y_pred_rf = best_rf.predict(X_test)
y_prob_rf = best_rf.predict_proba(X_test)[:, 1]

print("Decision Tree Test Acc:", accuracy_score(y_test, y_pred_dt))
print("Decision Tree Test F1:", f1_score(y_test, y_pred_dt))
print("Decision Tree Test AUC:", roc_auc_score(y_test, y_prob_dt))

print("Random Forest Test Acc:", accuracy_score(y_test, y_pred_rf))
print("Random Forest Test F1:", f1_score(y_test, y_pred_rf))
print("Random Forest Test AUC:", roc_auc_score(y_test, y_prob_rf))


# ========================
# 6b. Random Forest Raw Test Performance
# ========================
y_pred_rf_raw = best_rf_raw.predict(X_test)
y_prob_rf_raw = best_rf_raw.predict_proba(X_test)[:, 1]

print("Random Forest (Raw) Test Acc:", accuracy_score(y_test, y_pred_rf_raw))
print("Random Forest (Raw) Test F1:", f1_score(y_test, y_pred_rf_raw))
print("Random Forest (Raw) Test AUC:", roc_auc_score(y_test, y_prob_rf_raw))


# Store the results in a dictionary
results = {
    "Model": ["Decision Tree", "Random Forest", "Random Forest (Raw)"],
    "Accuracy": [
        accuracy_score(y_test, y_pred_dt),
        accuracy_score(y_test, y_pred_rf),
        accuracy_score(y_test, y_pred_rf_raw)
    ],
    "F1 Score": [
        f1_score(y_test, y_pred_dt),
        f1_score(y_test, y_pred_rf),
        f1_score(y_test, y_pred_rf_raw)
    ],
    "AUC": [
        roc_auc_score(y_test, y_prob_dt),
        roc_auc_score(y_test, y_prob_rf),
        roc_auc_score(y_test, y_prob_rf_raw)
    ]
}

# Create dataframe
df_results = pd.DataFrame(results)
print(df_results)


# ========================
# 7. 10-Fold CV Results
# ========================
cv = StratifiedKFold(n_splits=10, shuffle=True, random_state=42)
cv_results = []

for model, name in [(best_dt, "Decision Tree"), (best_rf, "Random Forest")]:
    acc = cross_val_score(model, X, y, cv=cv, scoring="accuracy")
    f1s = cross_val_score(model, X, y, cv=cv, scoring="f1")
    aucs = cross_val_score(model, X, y, cv=cv, scoring="roc_auc")
    cv_results.append({
        "Model": name,
        "CV Acc Mean": acc.mean(), "CV Acc Std": acc.std(),
        "CV F1 Mean": f1s.mean(), "CV F1 Std": f1s.std(),
        "CV AUC Mean": aucs.mean(), "CV AUC Std": aucs.std()
    })

cv_df = pd.DataFrame(cv_results)
print("\n=== 10-Fold CV Results ===")
print(cv_df)


# ========================
# 7b. Add to 10-Fold CV Results
# ========================
acc = cross_val_score(best_rf_raw, X, y, cv=cv, scoring="accuracy")
f1s = cross_val_score(best_rf_raw, X, y, cv=cv, scoring="f1")
aucs = cross_val_score(best_rf_raw, X, y, cv=cv, scoring="roc_auc")
cv_results.append({
    "Model": "Random Forest (Raw)",
    "CV Acc Mean": acc.mean(), "CV Acc Std": acc.std(),
    "CV F1 Mean": f1s.mean(), "CV F1 Std": f1s.std(),
    "CV AUC Mean": aucs.mean(), "CV AUC Std": aucs.std()
})

cv_df = pd.DataFrame(cv_results)
print("\n=== 10-Fold CV Results (with RF Raw) ===")
print(cv_df)